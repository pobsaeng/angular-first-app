System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var Student;
    return {
        setters:[],
        execute: function() {
            Student = (function () {
                function Student(fname, lname) {
                    this.fname = fname;
                    this.lname = lname;
                }
                return Student;
            }());
            exports_1("Student", Student);
        }
    }
});
//# sourceMappingURL=student.js.map