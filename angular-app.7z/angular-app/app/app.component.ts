import {Component, EventEmitter, Input, Output} from 'angular2/core';
import {Student} from './student';

@Component({
    selector: 'my-app',
    template: `
	            <h3>{{addTitle}}</h3>
				<div>
                    <table>
                    <tr><td><b>{{addMessage}}</b></td></tr>
                        <tr><td>First Number :</td>
                            <td><input (input)="num1=$event.target.value" /></td>
                        </tr>
                        
                        <tr><td>Second Number:</td>
                            <td><input (input)="num2=$event.target.value" /></td>
                        </tr>
                        
                         <tr><td></td>
                            <td><button (click)="calCulate()">Add</button></td>
                        </tr>
                        <tr><td></td></tr>
                        <tr><td><h2>Result is </h2></td>
                            <td><div id="divResult"></div></td>
                        </tr>
                    </table>
				</div>		
			  `
})
export class AppComponent {
    addTitle = '------Angular JS------';
    addMessage = 'Add Number'
    num1: '';
    num2: '';

    calCulate() {
        let result = (parseInt(this.num1) + parseInt(this.num2));
        document.getElementById('divResult').innerHTML = '<h2>[ '+result.toString()+' ] </h2>';
    }
} 